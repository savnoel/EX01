"""Ex01 - Chardle - A cute step toward Wordle."""

__author__ = "730604481"

chosen_word: str = input("Enter a 5-character word: ")
if len(chosen_word) != 5:
    print("Error: Word must contain 5 characters")
    exit()
else:
    character: str = input("Enter a single character: ")
if len(character) != 1:
    print("Error: Character must be a single character.") 
    exit()

print("Searching for " + character + " in " + chosen_word) 
n: int = 0
if (character == chosen_word[0]):
    print(str(character) + " found at index 0")
    n = n + 1
    
if (character == chosen_word[1]):
    print(str(character) + " found at index 1")
    n = n + 1

if (character == chosen_word[2]):
    print(str(character) + " found at index 2")
    n = n + 1

if (character == chosen_word[3]):
    print(str(character) + " found at index 3")
    n = n + 1

if (character == chosen_word[4]):
    print(str(character) + " found at index 4")
    n = n + 1

if n == 1:
    print(str(1) + " instance of " + str(character) + " found in " + chosen_word)
 
if n > 1:
    print(str(n) + " instances of " + str(character) + " found in " + chosen_word)

if n == 0:
    print("No instances of " + str(character) + " found in " + chosen_word)